<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container" id="loginContainer">
        <h1>Login</h1>
        <form action="" id="loginForm">
            <div class="input-group">
                <input type="email" id="email" placeholder="Email" required>
                <i class='bx bxs-envelope'></i>
            </div>
            <div class="input-group">
                <input type="password" id="password" placeholder="Password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <a href="#">Forgot Password</a>
            <button type="submit" class="login-btn">Login</button>
            <p>or login with social platforms</p>
            <div class="social-buttons">
                <a href="http://localhost/Google_login/index.php"><i class='bx bxl-google'></i></a>
                <a href="http://localhost/github/protected.php"><i class='bx bxl-github'></i></a>
            </div>
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>
