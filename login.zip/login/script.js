document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");

    loginForm.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent actual form submission

        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();

        if (email === "" || password === "") {
            alert("Please enter both email and password.");
            return;
        }
        

        // Simulate login verification
        console.log("Email:", email);
        console.log("Password:", password);

        alert("Login Successful!");

        // Redirect to dashboard (Change "dashboard.html" to your actual page)
        // window.location.href = "dashboard.html";
    });
});
