<?php
session_start();
$login = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'database/db.php';
    $uname = $_POST["uname"];
    $password = $_POST["password"];

// include('database/db.php');

// if($_SERVER['REQUEST_METHOD'] ==  "POST"){

//     if (isset($_POST['uname']) && isset($_POST['password'])){
//         $uname = $_POST['uname'];
//         $password = $_POST['password'];

        $sql = "SELECT password from user_table where uname= '$uname'";
        $result = mysqli_query($conn, $sql);                                                                                                                                                                          
        // echo "1";
        $num = mysqli_num_rows($result);
        if($num > 0){
            // echo "2";
            while($row=mysqli_fetch_assoc($result)){ 
                // echo "3";
                

                if($password == $row['password']){
                    
                    $login = true;
                    session_start();
                    $_SESSION["loggedin"] = TRUE;
                    $_SESSION["uname"] = $uname;

                    header("location: ../html/dashboard.php");
                }
                else{
                    $showError = "Invalid Credentials";
                    echo $showError;
                }
            }
        }

    }

   

// $sql = "SELECT  uname, password FROM user_table WHERE uname = '$uname' AND  password =  '$password'";
// $result = $conn->query($sql);

// }

// if ($result->num_rows > 0) {
//     $row = $result->fetch_assoc();
//     $stored_hashed_password = $row['password'];

//     // Verify the provided password against the stored hashed password
//     if (password_verify($password, $stored_hashed_password)) {
//         echo "Login successful!";
//     }
//     else {
//         echo "Invalid password.";
//     }
// //  else {
// //     echo "No user found with that username.";
// // }

// }
  
// echo $row['uname'];
// echo $row['password'];
// if ($result->num_rows > 0) {
//     header("location:../html/dashboard.php");
//  } 
// else {
// //     die('the combination is wrong');
// // }


?>