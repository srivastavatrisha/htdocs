var x=10;
console.log(document.getElementById("x"));