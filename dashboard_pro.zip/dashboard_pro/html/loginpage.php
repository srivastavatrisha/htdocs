<?php
include('insert.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link rel="stylesheet" href="../css/login.css">

</head>

<body>
    <form action="../php/login_handler.php" method="POST">
    <div class="login-box">
        <div class="login-header">
            <header>Login</header>
        </div>
        <div class="input-box">
            <input type="text" name="uname" class="input-field" placeholder="Username: " required>
        </div>
        <div class="input-box">
            <input type="password" name="password" class="input-field" placeholder="Password: " required>
        </div>
        <div class="forgot">
            <section>
                <input type="checkbox" id="check">
                <label for="check">Remember me</label>
            </section>
            <section>
                <a href="#">Forgot Password </a>
            </section>
        </div>
        <div class="input-submit">
            <button class="submit-btn" id="submit"></button>
            <label for="submit">Sign in</label>
        </div>
        <div class="input-submit">
            <button class="submit-btn" id="submit"></button>
            <label for="submit">Logout</label>
        </div>
        <div class="sign-up-link">
            <p>Don't have account ? <a href="#">Sign up</a></p>
        </div>
    </div>

</form>
</body>
</html>