<?php
include('insert.php');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>registration form</title>
    <link rel="stylesheet" href="../css/reg.css">
</head>
<body>
    <div class="container">
        <form action="registerhandler.php" method="POST">
            <h2>registration form</h2>
            <div class="content">
                <div class="input-box">
                    <label for="name">Full Name: </label>
                    <input type="text" name="fname" placeholder="Enter full name" required>
                </div>
                <div class="input-box">
                    <label for="email">Email: </label>
                    <input type="email" name="email" placeholder="Enter your valid email address" required>
                </div>
                <div class="input-box">
                    <label for="dateofjoining">Date of Joining: </label>
                    <input type="date" name="date" placeholder="Enter your Joiningdate" required>
                </div>
                <div class="content">
                    <div class="input-box">
                        <label for="password">Password: </label>
                        <input type="password" name="password" placeholder="Enter new password" required>
                </div>
                
                    <div class="input-box">
                        <label for="dob">Date of Birth: </label>
                        <input type="date" name="dob" placeholder="Enter your birthday" required>
                    </div>
                    <span class="gender-title">Gender: </span>
                    <div class="gender-category">
                        <input type="radio" name="gender" id="male">
                        <label for="gender">Male</label>
                        <input type="radio" name="gender" id="female">
                        <label for="gender">Female</label>
                        <input type="radio" name="gender" id="other">
                        <label for="gender">Other</label>
                    </div>
                    <div class="button-container">
                        <button type="submit">Register</button>
                    </div>

        </form>


    </div>
</body>
</html>