<?php
include ('insert.php');

$id = $_POST['id'];
// update data in mysql database 
$sql = "UPDATE student2 SET 
    fname = '" . $_POST['fname'] . "', 
    uname = '" . $_POST['uname'] . "', 
    email = '" . $_POST['email'] . "', 
   dob = '" . $_POST['dob'] . "' 
WHERE id = $id";
$result=mysqli_query($conn, $sql) or die ("this stuffedup");

if($result) {
    // Redirect to a success page
    header("Location: student.php");
    exit(); // Make sure to call exit after redirect
} else {
    echo "Error updating record: " . $conn->error;
}

// if successfully updated. 
// if($result){
// echo "Successful";
// echo "<BR>";
// echo "<a href='list_records.php'>View result</a>";
// }


?>
