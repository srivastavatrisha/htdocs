z<?php
include('insert.php');

session_start();

// remove all session variables
session_unset();


// destroy the session
session_destroy();

header("location: registration2.php");




if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $Sno = $_POST["Sno"];
    $Uname = $_POST["Uname"];
    $mobile_no = $_POST["mobile_no"];
    $status = $_POST["status"];
    $created_at = $_POST["created_at"];
    $updated_by = $_POST["updated_by"];
    $actions = $_POST["actions"];
}

  $sql = "SELECT * from user_table";
  $result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href= "../css/user.css">
</head>

<body>

<?php include('component/sidebar.php');  ?>

<div class="main--content">
    <div class="header--wrapper">
        <div class="header--title">
            <span>User</span><br>
            <h2>Dashboard</h2>
        </div>
        <div class="user--info">
            <div class="search--box">
                <i class="fa-solid fa-search"></i>
                <input type="text" placeholder="Search" />
            </div><br>
            <img src="./trisha.png" width="70px" height="70px" alt="">
        </div>
    </div>
     
    <div class="tabular--wrapper">
    <div class="table--container">
    
        <table class="table">
        <h3 align="left">User data table</h3>
        <thead>
            <tr>
                <th scope="col">Sno</th>
                <th scope="col">Uname</th>
                <th scope="col">mobile_no</th>
                <th scope="col">status</th>
                <th scope="col">created_at</th>
                <th scope="col">updated_by</th>
                <th scope="col">password</th>
                <th scope="col">actions</th>
            </tr>
        </thead>
        <tbody>
        <?php
         $sql = "SELECT * FROM  user_table";
         $result = mysqli_query($conn, $sql);
                  
        while($row = mysqli_fetch_assoc($result)){ ?>
        <tr>
        <th scope='row'><?php echo $row['Sno'] ?></th>
        <td><?php echo $row['Uname'] ?></td>
        <td><?php echo $row['mobile_no'] ?></td>              
        <td><?php echo $row['status'] ?></td>
        <td><?php echo $row['created_at'] ?></td>
        <td><?php echo $row['updated_by'] ?></td>
        <td><?php echo $row['password'] ?></td>
        <td> 
         <a type='button' class='edit btn btn-primary'>Edit</a> 
         <a  type='button'   class='view btn btn-primary'>View</a>
         <a type='button' href='' class='del btn btn-primary'>Delete</a>
         </td>
         </tr>
        <?php 
        }

        ?>
          



</div>
</div>


  
   

</body>
</html>