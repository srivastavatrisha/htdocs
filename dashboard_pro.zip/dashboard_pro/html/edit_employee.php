                        
<?php
include('insert.php');
session_start();
// echo $_SESSION["loggedin"];
// die();

if($_SESSION['loggedin'] != 1)
{
    header("location: loginpage.php");
}

// if($_SERVER['REQUEST_METHOD'] == 'POST'){
//     $fname = $_POST["fname"];
//     $lname = $_POST['lname'];
//     $email = $_POST["email"];
//     $date = $_POST["date"];
//     $date = $_POST["date"];
    
//   } 
  $id= $_GET['id'];
//   echo $id;

  $sql = "SELECT *  from  employee2 where id='$id' limit 1";
  $result = mysqli_query($conn, $sql);
  $user = mysqli_fetch_array($result);

  


//   echo $user['date'];
//   echo $user;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit employee</title>
    <link rel="stylesheet" href="../css/edit.css">
 
   
</head>
<body>
    <div class="container">
        <form action="update.php" method="POST">
            <h3>Edit Employee</h3>
            <div class="content">
                <div class="input-box">
                    <label for="name">First Name: </label>
                    <input type="text" name="fname" placeholder="Enter first name" value="<?php echo $user['fname'];?>">
                </div>
                <div class="input-box">
                    <label for="username">Last Name: </label>
                    <input type="text" name="lname" placeholder="Enter last name" value="<?php echo $user['lname'] ?? '';?>">
                </div>
                <div class="input-box">
                    <label for="email">Email: </label>
                    <input type="email" name="email" placeholder="Enter your valid email address" value="<?php echo $user['email'] ?? '';?>">
                </div>
                <div class="input-box">
                    <label for="dateofjoining">Date of Joining: </label>
                    <input type="date" name="hire_date" placeholder="Enter your Joiningdate" value="<?php echo $user['hire_date'] ?? '';?>">
                </div>
                <div class="input-box">
                    <label for="dateofbirth">Date of Birth: </label>
                    <input type="date" name="dob" placeholder="Enter your birth date" value="<?php echo $user['dob'] ?? '';?>">
                </div>
                <div class="button-container">
                <input name="id" type="hidden" id="id" value="<?php echo $user['id']; ?>"/>
                    <button type="submit">Edit</button>
                </div>                          
                

        </form>
    </div>
    
</body>
</html>