<?php
include ('insert.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/dash.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

   
</head>
<body>
  <?php 
    include('component/sidebar.php');  ?>

    <div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <span>Primary</span><br>
                <h2>Dashboard</h2>
            </div>
            <div class="user--info">
                <div class="search--box">
                    <i class="fa-solid fa-search"></i>
                    <input type="text" placeholder="Search" />
                </div><br>
                <img src="../assets/image.png" width="400px" height="400px" alt="">
            </div>
        </div>

        <div class="tabular--wrapper">
        <h3 class="main--title">Mark Attendance</h3>
        <div class="table--container">
        
        <div class="attendance">
        <label for="Attendance_Date">Date: </label>
        <input type="date" name="attendance_date" required>
        </div>
        
        
         <form action="/dashboard_pro/html/submit_attendance.php" method="post">
         <table>
            <tr>
                <th>Name</th>
                <th>Present</th>
                <th>Absent</th>
            </tr>
            <?php
                // Connect to the database
                $conn = mysqli_connect($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch students
                $sql = "SELECT * FROM student";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output each row
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>
                        <input type='hidden' name='student_id[]' value='" . htmlspecialchars($row['student_id'], ENT_QUOTES, 'UTF-8') . "'>
                        " . htmlspecialchars($row['Student_name'], ENT_QUOTES, 'UTF-8') . "
                      </td>";
                

                        echo "<td>
                                <input type='checkbox' class = 'present' name='status[]' value='1'>
                              </td>
                              <td>
                               <input type='checkbox' class = 'absent' name='status[]' value='0'>
                               </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='2'>No students found.</td></tr>";
                }
            
        ?>
        
        </table>
        <div class="btn">
        <button type="submit">Submit Attendance</button>

        </div>
        
    </form>
    <script>
        $(document).ready(function() {
        $('.present').click(function() {
            $(this).closest('tr').find('.absent').prop('disabled', true);
        });
        $('.absent').click(function() {
            $(this).closest('tr').find('.present').prop('disabled', true);
        });
        });
    </script>
</body>
</html>
