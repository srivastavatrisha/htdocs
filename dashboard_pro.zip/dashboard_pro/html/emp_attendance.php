<?php
include ('insert.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee attendance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/dash.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
<?php 
   include('component/sidebar.php');  ?>

   <div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <span>Primary</span><br>
                <h2>Dashboard</h2>
            </div>
            <div class="user--info">
                <div class="search--box">
                    <i class="fa-solid fa-search"></i>
                    <input type="text" placeholder="Search" />
                </div><br>
                <img src="../assets/image.png" width="400px" height="400px" alt="">
            </div>
        </div>

        <div class="tabular--wrapper">
            <h3 class="main--title">Employee Attendance List</h3>
            <div class="table--container">
            <table>
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Employee_name</th>
                            <th scope="col">Department</th>
                            <th scope="col">Entry_Time</th>
                            <th scope="col">Leaving_Time</th>
                            <th scope="col">Date</th>
                            <th scope="col">created_at</th>
                            <th scope="col">updated_by</th>
                            <th scope="col">Details</th>
                        </tr>
                    </thead>
                    <?php
                    $sql = "SELECT * FROM  emp_attendance";
                    $result = mysqli_query($conn, $sql);
                      
                    while($row = mysqli_fetch_assoc($result)){ ?>
                     <tr>
                     <th scope='row'><?php echo $row['ID'] ?>
                     </th>
                     <td><?php echo $row['Employee_name'] ?></td>
                     <td> <?php echo $row['Department'] ?></td>
                     <td> <?php echo $row['Entry_Time'] ?></td>
                     <td><?php echo $row['Leaving_Time'] ?></td>
                     <td><?php echo $row['Date'] ?></td>
                     <td><?php echo $row['created_at'] ?></td>
                     <td><?php echo $row['updated_by'] ?></td>
                     <td>
                        <a type='button'
                        class='view btn btn-primary'>View</a>
                      </td>
                      </tr>
                      <?php 
                       }

                      ?>
                       
                    </tbody>
                </table>
            </div>
        </div>




</body>
</html>