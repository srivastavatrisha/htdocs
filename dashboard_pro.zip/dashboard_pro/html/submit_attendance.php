<?php
include ('insert.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the submitted data
    $student_id = $_POST['student_id'];
    $status = $_POST['status'];
    // die(var_dump($status));
    foreach ($student_id as $key => $id) {
        $student_status = $status[$key];

        $stmt = $conn->prepare("INSERT INTO stu_attendance (student_id, status) VALUES (?, ?)");
    $stmt->bind_param("is", $student_id, $student_status);

    if (!$stmt->execute()) {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    }

    echo "Attendance marked successfully!";
}
?>