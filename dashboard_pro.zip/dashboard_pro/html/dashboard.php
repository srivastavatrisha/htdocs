
<?php
session_start();
// echo $_SESSION["loggedin"];
// die();

if($_SESSION['loggedin'] != 1)
{
    header("location: loginpage.php");
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "school_management_system";

$conn = mysqli_connect($servername, $username, $password, $database);

if(!$conn){
  die("Sorry we failed to connect: " . mysqli_connect_error());
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/dash.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>
   <?php 
   include('component/sidebar.php');  ?>

    <div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <span>Primary</span><br>
                <h2>Dashboard</h2>
            </div>
            <div class="user--info">
                <div class="search--box">
                    <i class="fa-solid fa-search"></i>
                    <input type="text" placeholder="Search" />
                </div><br>
                <img src="../assets/image.png" width="400px" height="400px" alt="">
            </div>
        </div>


        <div class="tabular--wrapper">
            <h3 class="main--title">Student data</h3>
            <div class="table--container">
                <table>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">id</th>
                                <th scope="col">Student_name</th>
                                <th scope="col">Course</th>
                                <th scope="col">Phone_no</th>
                                <th scope="col">Email</th>
                                <th scope="col">status</th>
                                <th scope="col">created_at</th>
                                <th scope="col">updated_by</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>

                     <?php

                      $sql = "SELECT * FROM student";
                      $result = mysqli_query($conn, $sql);
                    //   echo $result;
                    //   die();
                      while($row = mysqli_fetch_assoc($result)){
                      ?><tr>
                      <th scope='row'> <?php $row['student_id'] ?></th>
                      <td><?php echo $row['Student_name'] ?></td>
                      <td><?php echo $row['Course'] ?></td>
                      <td><?php echo $row['Phone_no'] ?></td>
                      <td><?php echo $row['Email'] ?></td>
                      <td><?php echo $row['status'] ?></td>
                     <td><?php echo $row['created_at'] ?></td>
                     <td><?php echo $row['updated_by'] ?></td>
                   <td> 
             <a type='button' href='edit_employee.php?id=<?php echo $row['id'] ?>' class='edit btn btn-primary'>Edit</a> 
             <a  type='button'  href='view_emp.php?id=<?php echo $row['id'] ?>' class='view btn btn-primary'>View</a>
             <a type='button' href='' class='del btn btn-primary'>Delete</a>
                </td>
                </tr>
                    <?php }
     
                     ?>

                      
                       
   
                </table>
            </div>
        </div>



    </div>
    </div>

</body>
</html>