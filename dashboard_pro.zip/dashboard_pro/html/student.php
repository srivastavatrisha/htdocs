<?php

session_start();
// echo $_SESSION["loggedin"];
// die();

// if($_SESSIoN['loggedin'] != 1)
// {
//     header("location: loginpage.php");
// }



$servername = "localhost";
$username = "root";
$password = "";
$database = "school_management_system";

$conn = mysqli_connect($servername, $username, $password, $database);

if(!$conn){
  die("Sorry we failed to connect: " . mysqli_connect_error());
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/dash.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>
  <?php include('component/sidebar.php'); ?>

    <div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <span>Student</span><br>
                <h2>Dashboard</h2>
            </div>
            <div class="user--info">
                <div class="search--box">
                    <i class="fa-solid fa-search"></i>
                    <input type="text" placeholder="Search" />
                </div><br>
                <img src="../assets/image.png" width="70px" height="70px" alt="">
            </div>
        </div>

                  
        <div class="tabular--wrapper">
        <div class="table--container">
        <a href="/dashboard_pro/html/student_registration.php"><div class="student">
         <button type="button" class="add btn btn-primary">Add Student</button>
        </div>
        </a>
            <table class="table">
            <h3 align="left">Student Data</h3>
            <thead>
                <tr>
                    <th scope="col">id</th>
                    <th scope="col">fname</th>
                    <th scope="col">uname</th>
                    <th scope="col">email</th>
                    <th scope="col">phone_no</th>
                    <th scope="col">password</th>
                    <th scope="col">dob</th>
                    <th scope="col">gender</th>
                    <th scope="col">created_at</th>
                    <th scope="col">updated_by</th>
                    <th scope="col">actions</th>
                </tr>
            </thead>
            <tbody>

                <?php
                      $sql = "SELECT * FROM student2";
                      $result = mysqli_query($conn, $sql);
                      
                      while($row = mysqli_fetch_assoc($result)){ ?>
                      <tr>
                      <th scope='row'><?php echo $row['id'] ?> </th>
                      <td><?php echo  $row['fname']?></td>
                      <td><?php echo $row['uname']?></td>
                      <td><?php echo $row['email']?></td>
                      <td><?php echo $row['phone_no']?></td>
                      <td><?php echo $row['password']?></td>
                      <td><?php echo $row['dob']?></td>
                      <td><?php echo $row['gender']?></td>
                      <td><?php echo $row['created_at']?> </td>
                      <td><?php echo $row['updated_by'] ?> </td>
                     <td> 
                     <a type='button' href="edit_student.php?id=<?php echo $row['id'] ?>" class='edit btn btn-primary'>Edit</a> 
                    <a typw='button' href="view_stu.php?id=<?php echo $row['id'] ?>" class='view btn btn-primary'>View</a>
                    <a type='button' class='del btn btn-primary'>Delete</a>
                    </td>
                     </tr>
                     <?php
                     }

                     ?>
                    
                
            </tbody>
        </table>
        </div>
        </div>



    </div>
    </div>

</body>
</html>