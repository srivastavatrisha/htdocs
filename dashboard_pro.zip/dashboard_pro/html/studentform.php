<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit data</title>
</head>
<body>
<form name="" action="insert-attendance.php" method="post">
    <?php
        include('insert.php');
        $result = $db->prepare("SELECT * FROM stu_attendance WHERE Student_Class='$classname' AND  Student_Section='$section'");
        $result->execute();
        for ($i = 0; $row = $result->fetch(); $i++) {
            ?>
            <tr>
                <td><input type="text" name="id" value="<?php echo $row['ID'] ?>"></input></td>
                <td><input type="text" name="stuname" value="<?php echo $row['Student_name'] ?>"></input></td>
                <td><input type="text" name="stuclass" value="<?php echo $row['Student_Class'] ?>"></input></td>
                <td><input type="text" name="section" value="<?php echo $row['Student_Section'] ?>"></input>
                    <input type="hidden" value="<?php echo date("Y-m-d"); ?>" name="attdate">
                <td>
                    <select name="attndc">
                        <option value="present">PRESENT</option>
                        <option value="absent">ABSENT</option>
                        <option value="leave">LEAVE</option>
                    </select>
                </td>
            </tr>
            <?php
        }
    ?>
    <input type="submit" value="submit">
</form>
</body>
</html>