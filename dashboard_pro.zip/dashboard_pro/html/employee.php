<?php

include('insert.php');

session_start();
// echo $_SESSION["loggedin"];
// die();

if($_SESSION['loggedin'] != 1)
{
    header("location: loginpage.php");
}
    
// if($_SESSION['loggedin'] != 1)
// {
//     header("location: loginpage.php");
// }

$servername = "localhost";
$username = "root";
$password = "";
$database = "school_management_system";

$conn = mysqli_connect($servername, $username, $password, $database);

if(!$conn){
  die("Sorry we failed to connect: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Design</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/dash.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  
</head>

<body>
    <?php include('component/sidebar.php');  ?>

    <div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <span>Employee</span><br>
                <h2>Dashboard</h2>
            </div>
            <div class="user--info">
                <div class="search--box">
                    <i class="fa-solid fa-search"></i>
                    <input type="text" placeholder="Search" />
                </div><br>
                <img src="../assets/image.png" width="70px" height="70px" alt="">
            </div>
        </div>
         
        <div class="tabular--wrapper">
        <div class="table--container">
        <a href="/dashboard_pro/html/employee_registration.php"><div class="employee">
         <button type="button" class="btn btn-primary">Add Employee</button>
        </div>
        </a>
            <table class="table">
            <h3 align="left">Employee Data</h3>
            <thead>
                <tr>
                    <th scope="col">id</th>
                    <th scope="col">fname</th>
                    <th scope="col">uname</th>
                    <th scope="col">email</th>
                    <th scope="col">mobile_no</th>
                    <th scope="col">dob</th>
                    <th scope="col">hire_date</th>
                    <th scope="col">salary</th>
                    <th scope="col">status</th>
                    <th scope="col">created_at</th>
                    <th scope="col">updated_by</th>
                    <th scope="col">actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
             $sql = "SELECT * FROM employee2";
             $result = mysqli_query($conn, $sql);
                      
            while($row = mysqli_fetch_assoc($result)){ ?>
            <tr>
            <th scope='row'><?php echo $row['id'] ?></th>
            <td><?php echo $row['fname'] ?></td>
            <td><?php echo $row['uname'] ?></td>
            <td><?php echo $row['email'] ?></td>
            <td><?php echo $row['mobile_no'] ?></td>
            <td><?php echo $row['dob'] ?></td>
            <td><?php echo $row['hire_date'] ?></td>
            <td><?php echo $row['salary'] ?></td>                
            <td><?php echo $row['status'] ?></td>
            <td><?php echo $row['created_at'] ?></td>
            <td><?php echo $row['updated_by'] ?></td>
            <td> 
             <a type='button' href="edit_employee.php?id=<?php echo $row['id'] ?>" class='edit btn btn-primary'>Edit</a> 
             <a  type='button'  href="view_emp.php?id=<?php echo $row['id'] ?>" class='view btn btn-primary'>View</a>
             <a type='button' href='' class='del btn btn-primary'>Delete</a>
             </td>
             </tr>
            <?php 
            }

            ?>
              



    </div>
    </div>

</body>
</html>