<?php
include('insert.php');

$name = $_REQUEST['fname'];
$email = $_REQUEST['email'];
$date = $_REQUEST['date'];
$password = $_REQUEST['password'];
$dob = $_REQUEST['dob'];
$gender = $_REQUEST['gender'];

// echo $name;
// echo $email;
// echo $date;
// echo $password;
// echo $dob;
// echo $gender;

$sql = "INSERT into registerhandler(name, email, date, password, dob, gender) VALUES('$name', '$email', '$date', '$password',  '$dob', '$gender')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


?>