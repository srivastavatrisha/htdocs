
<div class="sidebar">
        <div class="logo"> </div>
        <ul class="menu">
            <li class="active">
                <a href="/dashboard_pro/html/dashboard.php"><i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
             <a href="/dashboard_pro/html/profile.php"><i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
            <li>
                <a href="/dashboard_pro/html/student.php"><i class="fa-solid fa-user-pen"></i>
                    <span>Students</span>
                </a>
            </li>
            <li>
                <a href="/dashboard_pro/html/employee.php"><i class="fa-solid fa-user-tie"></i>
            <span>Employee</span>
            </a>
            </li>
            <li>
                <a href="/dashboard_pro/html/emp_attendance.php"><i class="fa-solid fa-book"></i>
            <span>Employee_attend...</span>
            </a>
            </li>
            <li>
                  <a href="/dashboard_pro/html/student_atten.php"><i class="fa-solid fa-book-open-reader"></i>
                <span> Student_attend...</span>
            </a>
            </li>
            <li>
                  <a href="/dashboard_pro/html/attendancesystem.php"><i class="fa-solid fa-clipboard-user"></i>
                <span>Mark Attendance</span>
            </a>
            </li>
            <li>
                <a href="#"><i class="fas fa-question-circle"></i>
                    <span>FAQ</span>
                </a>
            </li>
            <!-- <li>
                <a href="#"><i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li> -->
            <li class="logout">
                <a href="../html/logout.php"><i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </div>