<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/dash.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  
</head>
<body>
<?php 
    include('component/sidebar.php');  ?>

<div class="main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <span>Primary</span><br>
                <h2>Dashboard</h2>
            </div>
            <div class="user--info">
                <div class="search--box">
                    <i class="fa-solid fa-search"></i>
                    <input type="text" placeholder="Search" />
                </div><br>
                <img src="../assets/image.png" width="400px" height="400px" alt="">
            </div>
        </div>

        <div class="tabular--wrapper">
            <h3 class="main--title">My Profile</h3>
            <div class="table--container">
            <p>  
                Hello! I'm Trisha Srivastava lived in Lucknow . I have completed my 10th at RLB Memorial School and completed 12th at RLB Memorial School with Commerce with Informatics Practices.Currently, I pursuing  Bachelor of Computer Applications (BCA) at Techno Institute of Higher Studies. I am very much passionate related to do coding and love to solve so many errors and bugs in code. At last , I want to become a good Web Developer in future.
                    
                </p>

</body>
</html>