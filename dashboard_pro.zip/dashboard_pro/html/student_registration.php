<?php

include('insert.php');


if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $fname = $_POST["fname"];
    $uname = $_POST["uname"];
    $email = $_POST["email"];
    $phone_no = $_POST["phone_no"];
    $cname = $_POST["cname"];
    $password = $_POST["password"];
    $gender = $_POST["gender"];
    $created_at = $_POST["created_at"];
    $updated_by = $_POST["updated_by"];
    $actions = $_POST["actions"];
}

  $sql = "SELECT * from student2";
  $result = mysqli_query($conn, $sql);

//     $sql = "SELECT *  from  student2";
//   $result = mysqli_query($conn, $sql);
//   // echo $result;

//   $sql = "INSERT INTO student2 (name, mobile_no, email, created_at, updated_by)
// VALUES ('John Doe', 678934092,  'john@gmail.com', 10/09/2023, 'Vaibhav Mishra')";

// $sql = "INSERT INTO student2(name, mobile_no, email, created_at, updated_by) VALUES('Nikhil Sharma', 786547839, 'nikhil@gmail.com', 22/09/2024, 'Meenakshi')";

// $sql = "INSERT INTO student2(name, mobile_no, email, created_at, updated_by) VALUES ('Kajal Singh', 890763384, 'kajal@gmail.com',  23/09/2024, 'Aayush Singh')";
// echo $sql;

// if ($conn->query($sql) === TRUE) {
//   echo "New record created successfully";
// } else {
//   echo "Error: " . $sql . "<br>" . $conn->error;
// }

  
  $sql = "SELECT  * from  student2";
  $result = mysqli_query($conn, $sql);
  // echo $result;


//   if ($result) {
//     echo "New record created successfully";
//   } 
//   else {
//     echo "Error: " . $sql . "<br>" . $conn->error;
//   }
  
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student registration form</title>
    <link rel="stylesheet" href="../css/stu.css">
</head>

<body>
    <div class="container">
        <form action="student_handler.php" method="POST">
            <h2>Student Registration</h2>
            <div class="content">
                <div class="input-box">
                    <label for="name">Full Name: </label>
                    <input type="text" name="fname"  placeholder="Enter full name" required><br>
                </div>
                <div class="input-box">
                    <label for="username">Username: </label>
                    <input type="text" name="uname" placeholder="Enter username" required><br>
                </div>
                <div class="input-box">
                    <label for="email">Email: </label>
                    <input type="email" name="email"  placeholder="Enter your valid email address" required><br>
                </div>
                <div class="input-box">
                    <label for="Phone No.">Phone No: </label>
                    <input type="tel" name="phone_no"  placeholder="Enter phone no." required><br>
                </div>
                <div class="input-box">
                    <label for="Collegename">College Name: </label>
                    <input type="text" name="cname"  placeholder="Enter your Collegename" required><br>
                </div>
                <div class="input-box">
                    <label for="password">Password: </label>
                    <input type="password" name="password"  placeholder="Enter new password" required><br>
                </div>
                <div class="input-box">
                        <label for="dob">Date of Birth: </label>
                        <input type="date" name="dob" placeholder="Enter your birthday" required>
                    </div>
                <span class="gender-title">Gender: </span>
                <div class="gender-category">
                    <input type="radio" name="gender" id="male">
                    <label for="gender">Male</label>
                    <input type="radio" name="gender" id="female">
                    <label for="gender">Female</label>
                    <input type="radio" name="gender" id="other">
                    <label for="gender">Other</label>
                </div>
            </div>
            <div class="alert">
                <p>By clicking Sign up, you agree to our <a href="#">Terms,</a> <a href="#">Privacy Policy,</a> and <a href="#">Cookies Policy.</a> You may Privacy Policy and Cookies Policy. You may
                receive SMS notifications from us and can opt out at any time.</p>
            </div>
            <div class="button-container">
                <button type="submit">Register</button>
            </div>
        </form>
       <table border="2">
       <?php

    //    while($result=mysqli_fetch_array($result)){
    //     echo '<tr>';
    //     echo '<td>' .$result['name']. '</td>';
    //     echo '</tr>';
    //    }
       ?>
       </table>


        

</body>
</html>