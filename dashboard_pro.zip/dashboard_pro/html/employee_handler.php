<?php
include('insert.php');
//   if (!$conn) {
//     die("Connection failed: " . mysqli_connect_error());
//   }
  
//   $sql = "INSERT INTO student (name, email, mobile_no)
//   VALUES ('John Doe',  'john@example.com', 678900683)";
  
//   if (mysqli_query($conn, $sql)) {
//     echo "New record created successfully";
//   } else {
//     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
//   }

$fname = $_POST['fname'];
$uname= $_POST['uname'];
$email = $_POST['email'];
$date = $_POST['date'];
$password = $_POST['password'];
$dob = $_POST['dob'];
$gender = $_POST['gender'];


echo $fname;
echo $uname;
echo $email;
echo $date;
echo $password;
echo $dob;
echo $gender;

$sql = "INSERT into employee2(fname, uname, email, hire_date, password, dob, gender) VALUES('$fname', '$uname', '$email', '$date', '$password', '$dob', '$gender')";

// $sql = "INSERT INTO employee2 (name, mobile_no, hire_date, salary, status, created_at, updated_by)
// VALUES ('Shruti Dixit', 67890445, 2024-10-23 , 10000, '', 2024-07-16, 'Mohan Singh')";

// $sql = "INSERT INTO employee2(name, mobile_no, hire_date, salary, status,  created_at, updated_by) VALUES('Deepak Kumar', 78906788, 2024-10-23, 30000, '',  2024-09-22, 'Raj')";

// $sql = "INSERT INTO employee2(name, mobile_no, hire_date, salary, status, created_at, updated_by) VALUES('Shristhi Gupta', 66778989, 2023-10-12, 32000, '', 2024-08-24, 'Ankit Verma')";

// $sql = "INSERT INTO employee2(name, mobile_no, hire_date, salary, status, created_at, updated_by) VALUES('Shristhi Gupta', 66778989, 2023-10-12, 32000, '', 2024-08-24, 'Ankit Verma')";



if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

// $result = mysqli_query($mysqli, "INSERT into student values('', '$name', '$email', '$phoneno', '$cname')");
// if($result){
//     header ("location:student_insert.php");
// }
// else{
//     echo "Failed";
// }

// // Check connection

// if ($conn->connect_error) {
//   die("Connection failed: " . $conn->connect_error);
// }
// echo "Connected successfully";


?>