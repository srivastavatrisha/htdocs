<?php
include ('insert.php');

$id = $_POST['id'];
// update data in mysql database 
$sql = "UPDATE employee2 SET 
    fname = '" . $_POST['fname'] . "', 
    lname = '" . $_POST['lname'] . "', 
    email = '" . $_POST['email'] . "', 
    hire_date = '" . $_POST['hire_date'] . "' ,
   dob  = '" . $_POST['dob'] . "' 
WHERE id = $id";
$result = mysqli_query($conn, $sql) or die("SQL Error: " . mysqli_error($conn));

if($result) {
    // Redirect to a success page
    header("Location: employee.php");
    exit(); // Make sure to call exit after redirect
} 
else {
    echo "Error updating record: " . $conn->error;
}

// if successfully updated. 
// if($result){
// echo "Successful";
// echo "<BR>";
// echo "<a href='list_records.php'>View result</a>";
// }


?>
