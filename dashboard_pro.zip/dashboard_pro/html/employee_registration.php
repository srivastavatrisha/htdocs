<?php

include('insert.php');


if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $name = $_POST["name"];
    $mobile_no = $_POST["mobile_no"];
    $hire_date = $_POST["hire_date"];
    $salary = $_POST["salary"];
    $status = $_POST["status"];
    $created_at = $_POST["created_at"];
    $updated_by = $_POST["updated_by"];
    $actions = $_POST["actions"];
  } 

  $sql = "SELECT *  from  employee2";
  $result = mysqli_query($conn, $sql);
  // echo $result;

  ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee</title>
    <link rel="stylesheet" href="../css/emp.css">
    
   
</head>

<body>
    <div class="container">
        <form action="employee_handler.php" method="POST">
            <h2>Employee registration</h2>
            <div class="content">
                <div class="input-box">
                    <label for="name">Full Name: </label>
                    <input type="text" name="fname" placeholder="Enter full name" required>
                </div>
                <div class="input-box">
                    <label for="username">Username: </label>
                    <input type="text" name="uname" placeholder="Enter username" required>
                </div>
                <div class="input-box">
                    <label for="email">Email: </label>
                    <input type="email" name="email" placeholder="Enter your valid email address" required>
                </div>
                <div class="input-box">
                    <label for="dateofjoining">Date of Joining: </label>
                    <input type="date" name="date" placeholder="Enter your Joiningdate" required>
                </div>
                <div class="content">
                    <div class="input-box">
                        <label for="password">Password: </label>
                        <input type="password" name="password" placeholder="Enter new password" required>
                </div>
                
                    <div class="input-box">
                        <label for="dob">Date of Birth: </label>
                        <input type="date" name="dob" placeholder="Enter your birthday" required>
                    </div>
                    <span class="gender-title">Gender: </span>
                    <div class="gender-category">
                        <input type="radio" name="gender" id="male">
                        <label for="gender">Male</label>
                        <input type="radio" name="gender" id="female">
                        <label for="gender">Female</label>
                        <input type="radio" name="gender" id="other">
                        <label for="gender">Other</label>
                    </div>
                    <div class="button-container">
                        <button type="submit">Register</button>
                    </div>

        </form>


    </div>
</body>
</html>